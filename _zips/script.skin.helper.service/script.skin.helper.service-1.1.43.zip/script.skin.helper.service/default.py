#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
    script.skin.helper.service
    Helper service and scripts for Kodi skins
    Main script entry point
'''

from resources.lib.main_module import MainModule
MainModule()
