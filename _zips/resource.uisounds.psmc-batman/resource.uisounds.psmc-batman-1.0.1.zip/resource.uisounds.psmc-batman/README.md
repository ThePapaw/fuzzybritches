GUI Sounds for the PSMC's Batman skin.
